#include <iostream>
#include <fstream>
#include <map>
#include <string>
#include <iomanip>
#include <algorithm>

class ItemTracker {
private:
    std::map<std::string, int> itemFrequency;

public:
    // Constructor to read data from the input file and populate the map
    ItemTracker(const std::string& filename) {
        std::ifstream inputFile(filename);
        std::string item;

        if (!inputFile) {
            std::cerr << "Error opening file: " << filename << std::endl;
            return;
        }

        // Reading items from the input file and counting frequencies
        while (inputFile >> item) {
            // Convert item to lowercase
            std::transform(item.begin(), item.end(), item.begin(), ::tolower);
            itemFrequency[item]++;
        }

        inputFile.close();
        backupData("frequency.dat");
    }

    // Function to backup the frequency data to a file
    void backupData(const std::string& filename) {
        std::ofstream outputFile(filename);
        for (const auto& pair : itemFrequency) {
            outputFile << pair.first << " " << pair.second << std::endl;
        }
        outputFile.close();
    }

    // Function to get the frequency of a specific item
    int getFrequency(const std::string& item) {
        // Convert item to lowercase for consistent comparison
        std::string lowerItem = item;
        std::transform(lowerItem.begin(), lowerItem.end(), lowerItem.begin(), ::tolower);

        // Check if the item exists in the map, return frequency or 0 if not found
        auto it = itemFrequency.find(lowerItem);
        return (it != itemFrequency.end()) ? it->second : 0;
    }

    // Function to display all items and their frequencies
    void displayFrequencies() {
        for (const auto& pair : itemFrequency) {
            std::cout << pair.first << ": " << pair.second << std::endl;
        }
    }

    // Function to display histogram
    void displayHistogram() {
        for (const auto& pair : itemFrequency) {
            std::cout << std::setw(10) << pair.first << " ";
            for (int i = 0; i < pair.second; ++i) {
                std::cout << "*";
            }
            std::cout << std::endl;
        }
    }
};

int main() {
    ItemTracker tracker("CS210_Project_Three_Input_File.txt");
    int choice;

    do {
        std::cout << "Menu:\n";
        std::cout << "1. Check frequency of an item\n";
        std::cout << "2. Display all item frequencies\n";
        std::cout << "3. Display item histogram\n";
        std::cout << "4. Exit\n";
        std::cout << "Enter your choice: ";

        // Input validation for menu choice
        while (!(std::cin >> choice) || (choice < 1 || choice > 4)) {
            std::cout << "Invalid choice. Please enter a number between 1 and 4: ";
            std::cin.clear(); // Clear the error flag
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); // Discard invalid input
        }

        switch (choice) {
            case 1: {
                std::string item;

                // Input validation for item frequency check
                std::cout << "Enter item to check frequency: ";
                std::cin >> item;

                // Get the frequency and display it
                int frequency = tracker.getFrequency(item);
                if (frequency > 0) {
                    std::cout << item << " frequency: " << frequency << std::endl;
                } else {
                    std::cout << item << " is not available in the inventory." << std::endl;
                }
                break;
            }
            case 2:
                tracker.displayFrequencies();
                break;
            case 3:
                tracker.displayHistogram();
                break;
            case 4:
                std::cout << "Exiting program." << std::endl;
                break;
            default:
                std::cout << "Invalid choice. Please try again." << std::endl;
        }
    } while (choice != 4);

    return 0;
}
